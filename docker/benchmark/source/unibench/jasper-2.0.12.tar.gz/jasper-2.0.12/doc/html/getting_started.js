var getting_started =
[
    [ "Installation", "install.html", null ],
    [ "Organization of the Manual", "organization.html", null ]
];