/* 
 * mac_main.h  -- redefines main entry point
 */
 
#ifndef _mac_main_h
#define _mac_main_h

#undef main
#define main tool_main

#endif  /* _mac_main_h */

/*
 * Local Variables:
 * mode: c
 * c-basic-offset: 8
 * fill-column: 78
 * End:
 */
