/* #include "pgm2asc.h" */
#include "pnm.h"
/* wchar_t ocr1(struct box *box1, pix  *b, int cs); */
