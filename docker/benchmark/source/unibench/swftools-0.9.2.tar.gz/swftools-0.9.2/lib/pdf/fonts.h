#ifndef __fonts_h__
#define __fonts_h__

#ifdef __cplusplus
extern "C" {
#endif

extern char* d050000l_afm;
extern int d050000l_afm_len;
extern char* d050000l_pfb;
extern int d050000l_pfb_len;
extern char* n019003l_afm;
extern int n019003l_afm_len;
extern char* n019003l_pfb;
extern int n019003l_pfb_len;
extern char* n019004l_afm;
extern int n019004l_afm_len;
extern char* n019004l_pfb;
extern int n019004l_pfb_len;
extern char* n019023l_afm;
extern int n019023l_afm_len;
extern char* n019023l_pfb;
extern int n019023l_pfb_len;
extern char* n019024l_afm;
extern int n019024l_afm_len;
extern char* n019024l_pfb;
extern int n019024l_pfb_len;
extern char* n021003l_afm;
extern int n021003l_afm_len;
extern char* n021003l_pfb;
extern int n021003l_pfb_len;
extern char* n021004l_afm;
extern int n021004l_afm_len;
extern char* n021004l_pfb;
extern int n021004l_pfb_len;
extern char* n021023l_afm;
extern int n021023l_afm_len;
extern char* n021023l_pfb;
extern int n021023l_pfb_len;
extern char* n021024l_afm;
extern int n021024l_afm_len;
extern char* n021024l_pfb;
extern int n021024l_pfb_len;
extern char* n022003l_afm;
extern int n022003l_afm_len;
extern char* n022003l_pfb;
extern int n022003l_pfb_len;
extern char* n022004l_afm;
extern int n022004l_afm_len;
extern char* n022004l_pfb;
extern int n022004l_pfb_len;
extern char* n022023l_afm;
extern int n022023l_afm_len;
extern char* n022023l_pfb;
extern int n022023l_pfb_len;
extern char* n022024l_afm;
extern int n022024l_afm_len;
extern char* n022024l_pfb;
extern int n022024l_pfb_len;
extern char* s050000l_afm;
extern int s050000l_afm_len;
extern char* s050000l_pfb;
extern int s050000l_pfb_len;

#ifdef __cplusplus
}
#endif

#endif
