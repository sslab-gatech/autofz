#ifndef __cmyk_h__
#define __cmyk_h__
void convert_cmyk2rgb(float c,float m,float y,float k, unsigned char*r, unsigned char*g, unsigned char*b);
#endif
